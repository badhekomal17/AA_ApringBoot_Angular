package com.zensar.SpringCRUDwithRest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCruDwithRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
