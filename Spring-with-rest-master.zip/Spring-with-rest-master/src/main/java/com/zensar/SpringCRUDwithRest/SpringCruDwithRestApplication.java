package com.zensar.SpringCRUDwithRest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCruDwithRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCruDwithRestApplication.class, args);
	}

}
