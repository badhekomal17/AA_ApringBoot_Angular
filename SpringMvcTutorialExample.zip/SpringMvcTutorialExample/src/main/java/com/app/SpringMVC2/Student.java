package com.app.SpringMVC2;

import java.util.LinkedHashMap;

public class Student {
	private String fname;
	private String lname;
	private String country;
	private String planguage;
	private String[] hobbies;
	
	//Read the list from a Java Class
	private LinkedHashMap<String, String> countryoptions;
	
	 public Student() {
		 countryoptions = new LinkedHashMap<String, String>();
		 			countryoptions.put("IND", "India");
		 			countryoptions.put("UK", "United Kingdom");
                 }
	 
	public LinkedHashMap<String, String> getCountryoptions() {
		return countryoptions;
	}

	public void setCountryoptions(LinkedHashMap<String, String> countryoptions) {
		this.countryoptions = countryoptions;
	}

	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	 public String getPlanguage() {
         return planguage;
	 }
	 public void setPlanguage(String planguage) {
         this.planguage = planguage;
	 }

	public String[] getHobbies() {
		return hobbies;
	}

	public void setHobbies(String[] hobbies) {
		this.hobbies = hobbies;
	}
	 
} 