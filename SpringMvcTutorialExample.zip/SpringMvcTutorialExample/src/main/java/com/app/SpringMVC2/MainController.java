package com.app.SpringMVC2;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MainController {
 @RequestMapping("/home_page")
 public String showPage() {
 return "homepage" ;
 }
 @RequestMapping("/about_us")
 public String showPage2() {
 return "about" ;
 }
 @RequestMapping("/general-form")
 public String showForm() {
             return "genform" ;          
 }
 @RequestMapping("/processform")
 public String getFormData() {
             return "formdata";
   }
} 
